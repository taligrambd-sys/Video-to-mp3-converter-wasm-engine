#!/usr/bin/env bash
# build-v4.sh - Build vidmp3.wasm v4 ("parallel fast" release).
#
# What v4 adds vs v3 (speed only - output quality/bytes unchanged for
# the single-convert path):
#   1. C core src/vidmp3-v4.c: vidmp3_convert() is unchanged in
#      behaviour (it is now a thin wrapper over a shared impl), and
#      two exports are added:
#        - vidmp3_probe(path) -> audio duration in microseconds.
#        - vidmp3_convert_range(path, out, kbps, startUs, endUs,
#          writeId3) -> converts only [startUs, endUs), seeking first
#          and trimming at sample precision at the audio FIFO; with
#          writeId3 == 0 the MP3 muxer writes no ID3v2 header, so the
#          segment is a raw frame stream.
#      Long files can thus be split into time segments, encoded in
#      parallel by several Web Workers, and the segment MP3s simply
#      concatenated. Encoder settings (libmp3lame, bit_rate only),
#      demuxer/decoder set and sample-rate logic are identical to
#      v1/v2/v3 - a segment is encoded exactly like a full file.
#   2. The worker (vidmp3-worker.js v4) additionally serves 'probe'
#      and 'convert-range' messages; the wrapper
#      (video-to-mp3-stream.js v4) probes, splits, runs the segments
#      in parallel and concatenates, falling back to the v3 single
#      convert on any problem.
#
# The link recipe is exactly v3's shipped one (build-v3.sh): linked
# against prefix-o2/ - FFmpeg libs from the v2 build plus LAME
# rebuilt with CFLAGS="-O2" (the original library build had compiled
# LAME with no -O flag at all). MODULARIZE=1, EXPORT_NAME=
# VidMp3Module, ALLOW_MEMORY_GROWTH=1, INITIAL_MEMORY=33554432,
# -lworkerfs.js, WORKERFS exported. Single-threaded: no COOP/COEP
# headers needed on the host.
#
# Usage:
#   ./build-v4.sh            -> build-v4/
#
# Prerequisites: Emscripten SDK (this script sources ~/tools/emsdk
# if present) and the static libs already built in prefix-o2/
# (see build-v3.sh's header for how prefix-o2 was produced).

set -e
cd "$(dirname "$0")"
ROOT="$PWD"
SRC="$ROOT/src"

if [ -f "$HOME/tools/emsdk/emsdk_env.sh" ]; then
    # shellcheck disable=SC1091
    . "$HOME/tools/emsdk/emsdk_env.sh" > /dev/null
fi
command -v emcc > /dev/null || { echo "emcc not found - activate Emscripten first"; exit 1; }

PREFIX="$ROOT/prefix-o2"
OUT="$ROOT/build-v4"
mkdir -p "$OUT"
[ -f "$PREFIX/lib/libavformat.a" ] || { echo "static libs missing in $PREFIX/lib"; exit 1; }

emcc -O2 "$SRC/vidmp3-v4.c" \
    -I"$PREFIX/include" \
    -L"$PREFIX/lib" \
    -lavformat -lavcodec -lswresample -lavutil -lmp3lame -lm \
    -lworkerfs.js \
    -sMODULARIZE=1 -sEXPORT_NAME=VidMp3Module \
    -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=33554432 \
    -sEXPORTED_FUNCTIONS='["_vidmp3_convert","_vidmp3_probe","_vidmp3_convert_range","_vidmp3_last_error","_vidmp3_version","_malloc","_free"]' \
    -sEXPORTED_RUNTIME_METHODS='["ccall","cwrap","FS","UTF8ToString","WORKERFS"]' \
    -o "$OUT/vidmp3.js"

echo
echo "Built v4: $OUT/vidmp3.js + vidmp3.wasm"
ls -la "$OUT/vidmp3.js" "$OUT/vidmp3.wasm"
