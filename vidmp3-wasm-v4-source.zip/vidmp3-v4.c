/*
 * vidmp3.c - Video-to-MP3 conversion core for WebAssembly.
 *
 * Part of the Kaalsoft VideoToMp3 WASM module. Built on a trimmed
 * FFmpeg 6.1.2 (common video/audio demuxers, common audio decoders,
 * libswresample) with the LAME 3.100 MP3 encoder as the only encoder
 * and the MP3 muxer as the only output format.
 *
 * Public C API (exported to JavaScript):
 *   int         vidmp3_convert(const char* inPath, const char* outPath,
 *                              int bitrateKbps);
 *   int64_t     vidmp3_probe(const char* inPath);
 *   int         vidmp3_convert_range(const char* inPath,
 *                              const char* outPath, int bitrateKbps,
 *                              int64_t startUs, int64_t endUs,
 *                              int writeId3);
 *   const char* vidmp3_last_error(void);
 *   const char* vidmp3_version(void);
 *
 * vidmp3_convert() blocks until the conversion finishes. Progress is
 * reported (0..100, percent of total audio duration processed) to the
 * JS function stored in globalThis.__vidmp3_progress whenever the value
 * changes.
 *
 * Return value: 0 on success, negative on failure. On failure,
 * vidmp3_last_error() returns a human-readable description.
 *
 * v3 change (this file vs vidmp3.c): ONLY the way the input is opened.
 * The input is read through a custom AVIOContext with a 1 MiB buffer
 * over stdio (fopen/fread/fseeko), instead of the default file
 * protocol. On the WORKERFS streaming path used for large files, the
 * default protocol's small reads turned into a storm of tiny
 * FileReaderSync/Blob.slice round-trips, which - not the encoder - is
 * what made v2 slower than v1 on the phone. Demuxing, decoding,
 * resampling and the MP3 encoder setup (libmp3lame, bit_rate only)
 * are byte-for-byte identical to v1/v2, so output quality and the
 * output bytes are unchanged.
 *
 * v4 additions (this file vs vidmp3-v3.c): vidmp3_probe() and
 * vidmp3_convert_range(). The range converter shares the exact same
 * implementation as vidmp3_convert() (which is now a thin wrapper);
 * it only adds: a seek to the range start, sample-accurate trimming
 * at the audio FIFO (samples before startUs / after endUs never reach
 * the encoder), progress measured within the range, and the option
 * to suppress the ID3v2 header (writeId3 == 0) so parallel segment
 * outputs are raw MP3 frame streams that concatenate cleanly.
 * Encoder settings, bitrate handling and sample-rate logic are
 * untouched - a segment is encoded exactly like a full file.
 *
 * License: this file is MIT-licensed (see README). The FFmpeg and LAME
 * libraries it links against are LGPL v2.1 (see LICENSE files).
 */

#include <errno.h>
#include <math.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <libavformat/avformat.h>
#include <libavformat/avio.h>
#include <libavcodec/avcodec.h>
#include <libswresample/swresample.h>
#include <libavutil/avutil.h>
#include <libavutil/opt.h>
#include <libavutil/channel_layout.h>
#include <libavutil/samplefmt.h>
#include <libavutil/audio_fifo.h>

/* ------------------------------------------------------------------ */
/* Error reporting                                                    */
/* ------------------------------------------------------------------ */

static char g_errbuf[1024];

static void set_error(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_errbuf, sizeof(g_errbuf), fmt, ap);
    va_end(ap);
}

static void set_av_error(const char *what, int errnum)
{
    char tmp[AV_ERROR_MAX_STRING_SIZE];
    if (av_strerror(errnum, tmp, sizeof(tmp)) == 0)
        set_error("%s: %s", what, tmp);
    else
        set_error("%s (error %d)", what, errnum);
}

const char *vidmp3_last_error(void)
{
    return g_errbuf;
}

/* ------------------------------------------------------------------ */
/* Progress callback                                                  */
/* ------------------------------------------------------------------ */

/*
 * The JS wrapper sets globalThis.__vidmp3_progress to a function before
 * calling vidmp3_convert(). This EM_JS import calls it directly, so no
 * function-pointer / table-growth plumbing is needed and the module
 * works with a non-growable WASM table.
 */
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
EM_JS(void, vidmp3_js_progress, (int percent), {
    if (typeof globalThis !== 'undefined' &&
        typeof globalThis.__vidmp3_progress === 'function') {
        try { globalThis.__vidmp3_progress(percent); } catch (e) {}
    }
});
#else
static void vidmp3_js_progress(int percent) { (void)percent; }
#endif

static int g_last_percent = -1;

static void report_progress(int64_t position, int64_t total)
{
    int pct;
    if (total <= 0) {
        pct = 0;
    } else {
        double ratio = (double)position / (double)total;
        if (ratio < 0.0) ratio = 0.0;
        if (ratio > 1.0) ratio = 1.0;
        pct = (int)(ratio * 100.0);
    }
    if (pct != g_last_percent) {
        g_last_percent = pct;
        vidmp3_js_progress(pct);
    }
}

/* ------------------------------------------------------------------ */
/* Version                                                            */
/* ------------------------------------------------------------------ */

const char *vidmp3_version(void)
{
    static char vbuf[256];
    unsigned avf = avformat_version();
    unsigned avc = avcodec_version();
    unsigned swr = swresample_version();
    snprintf(vbuf, sizeof(vbuf),
             "vidmp3-wasm 1.0 (libavformat %u.%u.%u, libavcodec %u.%u.%u, "
             "libswresample %u.%u.%u, LAME 3.100)",
             AV_VERSION_MAJOR(avf), AV_VERSION_MINOR(avf), AV_VERSION_MICRO(avf),
             AV_VERSION_MAJOR(avc), AV_VERSION_MINOR(avc), AV_VERSION_MICRO(avc),
             AV_VERSION_MAJOR(swr), AV_VERSION_MINOR(swr), AV_VERSION_MICRO(swr));
    return vbuf;
}

/* ------------------------------------------------------------------ */
/* Encoding helpers                                                   */
/* ------------------------------------------------------------------ */

static int drain_encoder_packets(AVCodecContext *ectx, AVFormatContext *ofmt,
                                 AVStream *ost)
{
    AVPacket *pkt = av_packet_alloc();
    int ret = 0;
    if (!pkt)
        return AVERROR(ENOMEM);
    for (;;) {
        int r = avcodec_receive_packet(ectx, pkt);
        if (r == AVERROR(EAGAIN) || r == AVERROR_EOF) {
            break;
        }
        if (r < 0) {
            ret = r;
            break;
        }
        av_packet_rescale_ts(pkt, ectx->time_base, ost->time_base);
        pkt->stream_index = ost->index;
        if ((r = av_interleaved_write_frame(ofmt, pkt)) < 0) {
            av_packet_unref(pkt);
            ret = r;
            break;
        }
        av_packet_unref(pkt);
    }
    av_packet_free(&pkt);
    return ret;
}

/*
 * Encode exactly `n` samples taken from the FIFO (n must be <= the
 * encoder frame size, and < frame size only for the final frame).
 */
static int encode_from_fifo(AVCodecContext *ectx, AVAudioFifo *fifo, int n,
                            AVFrame *eframe, int64_t *next_pts,
                            AVFormatContext *ofmt, AVStream *ost)
{
    int r = av_audio_fifo_read(fifo, (void **)eframe->data, n);
    if (r < 0)
        return r;
    eframe->nb_samples = n;
    eframe->pts = *next_pts;
    *next_pts += n;
    r = avcodec_send_frame(ectx, eframe);
    if (r < 0)
        return r;
    return drain_encoder_packets(ectx, ofmt, ost);
}

/* ------------------------------------------------------------------ */
/* Range trimming (v4)                                                */
/* ------------------------------------------------------------------ */

/*
 * State for vidmp3_convert_range(). Trimming happens at the audio
 * FIFO, in OUTPUT samples:
 *
 *   - skip_remaining: samples at the FIFO head that still belong to
 *     the pre-start region. The seek lands on a keyframe at or before
 *     startUs; the first decoded frame's timestamp tells us exactly
 *     how many output samples precede startUs, and they are drained
 *     from the FIFO instead of being encoded.
 *   - target: how many output samples [startUs, endUs) spans.
 *   - encoded: samples handed to the encoder so far.
 *   - done: set once encoded + queued samples cover the target, so
 *     the demux loop can stop reading early.
 *
 * The mapping "output sample k <-> input time" is anchored at the
 * first decoded frame's best-effort timestamp; from there decoded
 * audio is contiguous, so counting produced samples is enough. (The
 * resampler's own few-sample filter delay shifts a boundary by far
 * less than one MP3 frame.)
 */
typedef struct RangeTrim {
    int64_t start_us;
    int64_t end_us;
    AVRational tb;          /* input stream time base */
    int out_rate;           /* encoder (output) sample rate */
    int started;            /* skip/target initialised from 1st frame */
    int64_t skip_remaining;
    int64_t target;
    int64_t encoded;
    int done;
} RangeTrim;

/*
 * Encode from the FIFO under the range cap: full encoder frames while
 * at least a full frame of budget remains; on the final flush, one
 * last partial frame with whatever budget is left.
 */
static int range_encode_available(AVCodecContext *ectx, AVAudioFifo *fifo,
                                  AVFrame *eframe, int64_t *next_pts,
                                  AVFormatContext *ofmt, AVStream *ost,
                                  RangeTrim *tc, int final_flush)
{
    for (;;) {
        int avail = av_audio_fifo_size(fifo);
        int64_t room = tc->target - tc->encoded;
        int r;
        if (room <= 0) {
            tc->done = 1;
            return 0;
        }
        if (avail <= 0)
            return 0; /* nothing queued right now - NOT done: more
                       * input frames are still coming. (An empty FIFO
                       * mid-stream just means the encoder has caught
                       * up with the decoder.) */
        if (avail >= ectx->frame_size && room >= ectx->frame_size) {
            r = encode_from_fifo(ectx, fifo, ectx->frame_size, eframe,
                                 next_pts, ofmt, ost);
            if (r < 0)
                return r;
            tc->encoded += ectx->frame_size;
        } else if (final_flush) {
            int n = (int)(avail < room ? avail : room);
            r = encode_from_fifo(ectx, fifo, n, eframe, next_pts,
                                 ofmt, ost);
            if (r < 0)
                return r;
            tc->encoded += n;
            tc->done = 1;
            return 0;
        } else {
            break;
        }
    }
    if (tc->encoded + av_audio_fifo_size(fifo) >= tc->target)
        tc->done = 1;
    return 0;
}

/*
 * Resample one decoded frame through SwrContext into the FIFO, then
 * encode every full encoder frame that becomes available. When `tc`
 * is non-NULL (range mode), samples are trimmed at the FIFO to the
 * requested [startUs, endUs) window instead.
 */
static int push_decoded_frame(SwrContext *swr, AVFrame *dframe,
                              AVAudioFifo *fifo, AVCodecContext *ectx,
                              AVFrame *eframe, int64_t *next_pts,
                              AVFormatContext *ofmt, AVStream *ost,
                              RangeTrim *tc)
{
    /* Range mode: anchor the trim counters at the first decoded
     * frame's timestamp (the seek may have landed slightly early). */
    if (tc && !tc->started) {
        int64_t base_us = tc->start_us; /* fallback: assume exact */
        int64_t ts = dframe->best_effort_timestamp;
        int64_t skip, tgt;
        if (ts != AV_NOPTS_VALUE)
            base_us = av_rescale_q(ts, tc->tb, AV_TIME_BASE_Q);
        skip = (int64_t)llround((double)(tc->start_us - base_us) *
                                (double)tc->out_rate / 1000000.0);
        tc->skip_remaining = skip > 0 ? skip : 0;
        tgt = (int64_t)llround((double)(tc->end_us - tc->start_us) *
                               (double)tc->out_rate / 1000000.0);
        tc->target = tgt > 0 ? tgt : 0;
        tc->started = 1;
    }

    int64_t in_rate = 0, out_rate = 0;
    av_opt_get_int(swr, "in_sample_rate", 0, &in_rate);
    av_opt_get_int(swr, "out_sample_rate", 0, &out_rate);
    int64_t delay = swr_get_delay(swr, in_rate);
    int dst_nb = (int)av_rescale_rnd(delay + dframe->nb_samples, out_rate,
                                     in_rate, AV_ROUND_UP);
    if (dst_nb <= 0)
        return 0;

    uint8_t *outbuf[2] = { NULL, NULL };
    int channels = ectx->ch_layout.nb_channels;
    int ret = av_samples_alloc(outbuf, NULL, channels, dst_nb,
                               AV_SAMPLE_FMT_S16P, 0);
    if (ret < 0)
        return ret;
    int n = swr_convert(swr, outbuf, dst_nb,
                        (const uint8_t **)dframe->data, dframe->nb_samples);
    if (n > 0) {
        ret = av_audio_fifo_write(fifo, (void **)outbuf, n);
        av_freep(&outbuf[0]);
        if (ret < 0)
            return ret;
        if (!tc) {
            while (av_audio_fifo_size(fifo) >= ectx->frame_size) {
                ret = encode_from_fifo(ectx, fifo, ectx->frame_size, eframe,
                                       next_pts, ofmt, ost);
                if (ret < 0)
                    return ret;
            }
        } else {
            if (tc->skip_remaining > 0) {
                int avail0 = av_audio_fifo_size(fifo);
                int drain = tc->skip_remaining < avail0
                                ? (int)tc->skip_remaining : avail0;
                if (drain > 0) {
                    av_audio_fifo_drain(fifo, drain);
                    tc->skip_remaining -= drain;
                }
            }
            ret = range_encode_available(ectx, fifo, eframe, next_pts,
                                         ofmt, ost, tc, 0);
            if (ret < 0)
                return ret;
        }
        return 0;
    }
    av_freep(&outbuf[0]);
    return n < 0 ? n : 0;
}

/* ------------------------------------------------------------------ */
/* Input opening (v3): custom AVIOContext with a 1 MiB buffer         */
/* ------------------------------------------------------------------ */

/*
 * FFmpeg is handed input through an AVIOContext whose buffer is 1 MiB
 * and whose read callback is a plain stdio fread(). Whatever sits
 * behind the path (MEMFS memory file or a WORKERFS-mounted browser
 * File) is then touched in 1 MiB gulps instead of the default file
 * protocol's small reads. A matching setvbuf() stops stdio itself
 * from chopping those requests up again underneath us.
 *
 * If anything in this path fails, vidmp3_convert() falls back to the
 * plain avformat_open_input(path) used by v1/v2, so behaviour can
 * never get worse than before.
 */

#define VIDMP3_AVIO_BUFFER_SIZE (1 << 20)

typedef struct VidMp3StdioAvio {
    FILE *fp;
    unsigned char *stdio_buf; /* setvbuf() buffer; owned by us */
} VidMp3StdioAvio;

static int vidmp3_stdio_read(void *opaque, uint8_t *buf, int size)
{
    VidMp3StdioAvio *ctx = (VidMp3StdioAvio *)opaque;
    size_t n = fread(buf, 1, (size_t)size, ctx->fp);
    if (n > 0)
        return (int)n;
    if (feof(ctx->fp))
        return AVERROR_EOF;
    return AVERROR(errno ? errno : EIO);
}

static int64_t vidmp3_stdio_seek(void *opaque, int64_t offset, int whence)
{
    VidMp3StdioAvio *ctx = (VidMp3StdioAvio *)opaque;

    if (whence & AVSEEK_SIZE) {
        off_t cur = ftello(ctx->fp);
        off_t end;
        if (cur < 0)
            return AVERROR(errno);
        if (fseeko(ctx->fp, 0, SEEK_END) < 0)
            return AVERROR(errno);
        end = ftello(ctx->fp);
        if (fseeko(ctx->fp, cur, SEEK_SET) < 0)
            return AVERROR(errno);
        return end;
    }
    whence &= ~AVSEEK_FORCE;
    if (whence != SEEK_SET && whence != SEEK_CUR && whence != SEEK_END)
        return AVERROR(EINVAL);
    if (fseeko(ctx->fp, (off_t)offset, whence) < 0)
        return AVERROR(errno ? errno : EIO);
    {
        off_t pos = ftello(ctx->fp);
        return pos < 0 ? AVERROR(errno) : pos;
    }
}

/*
 * Open `path` through the custom AVIO and hand the probed context to
 * the caller. On success returns 0; *out_ctx must be released AFTER
 * avformat_close_input() with vidmp3_close_input_avio() (FFmpeg marks
 * a caller-supplied pb as AVFMT_FLAG_CUSTOM_IO and does not close it).
 * On failure returns a negative AVERROR code and nothing is left
 * allocated, so the caller can fall back to a plain open.
 */
static int vidmp3_open_input_avio(const char *path,
                                  AVFormatContext **out_ifmt,
                                  AVIOContext **out_avio,
                                  VidMp3StdioAvio **out_ctx)
{
    FILE *fp;
    VidMp3StdioAvio *ctx = NULL;
    unsigned char *avio_buf = NULL;
    AVIOContext *avio = NULL;
    AVFormatContext *ifmt = NULL;
    int ret;

    *out_ifmt = NULL;
    *out_avio = NULL;
    *out_ctx = NULL;

    fp = fopen(path, "rb");
    if (!fp)
        return AVERROR(errno ? errno : ENOENT);

    ctx = (VidMp3StdioAvio *)av_mallocz(sizeof(*ctx));
    avio_buf = (unsigned char *)av_malloc(VIDMP3_AVIO_BUFFER_SIZE);
    if (!ctx || !avio_buf) {
        ret = AVERROR(ENOMEM);
        goto fail;
    }
    ctx->fp = fp;

    /* Keep stdio from fragmenting the AVIO layer's 1 MiB requests:
     * give the FILE its own 1 MiB buffer before any I/O happens. */
    ctx->stdio_buf = (unsigned char *)av_malloc(VIDMP3_AVIO_BUFFER_SIZE);
    if (ctx->stdio_buf)
        setvbuf(fp, (char *)ctx->stdio_buf, _IOFBF, VIDMP3_AVIO_BUFFER_SIZE);

    avio = avio_alloc_context(avio_buf, VIDMP3_AVIO_BUFFER_SIZE, 0, ctx,
                              vidmp3_stdio_read, NULL, vidmp3_stdio_seek);
    if (!avio) {
        ret = AVERROR(ENOMEM);
        goto fail;
    }
    avio_buf = NULL; /* owned by the AVIOContext now */

    ifmt = avformat_alloc_context();
    if (!ifmt) {
        ret = AVERROR(ENOMEM);
        goto fail;
    }
    ifmt->pb = avio;
    /* Empty filename: format probing works purely off the data. */
    ret = avformat_open_input(&ifmt, "", NULL, NULL);
    if (ret < 0) {
        /* avformat_open_input() already freed ifmt (and did not touch
         * our custom AVIO), so undo the rest of this helper here. */
        avio_context_free(&avio);
        fclose(fp);
        av_freep(&ctx->stdio_buf);
        av_freep(&ctx);
        return ret;
    }

    *out_ifmt = ifmt;
    *out_avio = avio;
    *out_ctx = ctx;
    return 0;

fail:
    if (avio)
        avio_context_free(&avio);
    else
        av_freep(&avio_buf);
    fclose(fp);
    if (ctx) {
        av_freep(&ctx->stdio_buf);
        av_freep(&ctx);
    }
    return ret;
}

/* Release what vidmp3_open_input_avio() handed out. Call only after
 * avformat_close_input() on the matching AVFormatContext. */
static void vidmp3_close_input_avio(AVIOContext *avio, VidMp3StdioAvio *ctx)
{
    if (avio)
        avio_context_free(&avio);
    if (ctx) {
        if (ctx->fp)
            fclose(ctx->fp);
        av_freep(&ctx->stdio_buf);
        av_freep(&ctx);
    }
}

/* ------------------------------------------------------------------ */
/* Duration probe (v4)                                                */
/* ------------------------------------------------------------------ */

/*
 * Return the duration of the best audio stream in microseconds
 * (AV_TIME_BASE units), or a negative value on error (with
 * vidmp3_last_error() set). Used by the parallel wrapper to decide
 * how to split a file into segments.
 */
int64_t vidmp3_probe(const char *in_path)
{
    AVFormatContext *ifmt = NULL;
    AVIOContext *in_avio = NULL;
    VidMp3StdioAvio *in_ctx = NULL;
    int64_t dur = AV_NOPTS_VALUE;
    int ret;

    g_errbuf[0] = '\0';

    ret = vidmp3_open_input_avio(in_path, &ifmt, &in_avio, &in_ctx);
    if (ret < 0)
        ret = avformat_open_input(&ifmt, in_path, NULL, NULL);
    if (ret < 0) {
        set_av_error("Cannot open the input file "
                     "(unsupported format or corrupted data)", ret);
        return -1;
    }
    ret = avformat_find_stream_info(ifmt, NULL);
    if (ret < 0) {
        set_av_error("Cannot read stream information from the input file", ret);
        avformat_close_input(&ifmt);
        vidmp3_close_input_avio(in_avio, in_ctx);
        return -2;
    }

    int astream = av_find_best_stream(ifmt, AVMEDIA_TYPE_AUDIO, -1, -1,
                                      NULL, 0);
    if (astream < 0) {
        set_error("No audio stream found in the input file");
        avformat_close_input(&ifmt);
        vidmp3_close_input_avio(in_avio, in_ctx);
        return -3;
    }
    AVStream *ist = ifmt->streams[astream];
    if (ist->duration != AV_NOPTS_VALUE && ist->duration > 0) {
        dur = av_rescale_q(ist->duration, ist->time_base, AV_TIME_BASE_Q);
    } else if (ifmt->duration != AV_NOPTS_VALUE && ifmt->duration > 0) {
        dur = ifmt->duration;
    }

    avformat_close_input(&ifmt);
    vidmp3_close_input_avio(in_avio, in_ctx);

    if (dur == AV_NOPTS_VALUE || dur <= 0) {
        set_error("Cannot determine the duration of the input file");
        return -4;
    }
    return dur;
}

/* ------------------------------------------------------------------ */
/* Main entry point                                                   */
/* ------------------------------------------------------------------ */

/*
 * Shared implementation for vidmp3_convert() (range_mode == 0) and
 * vidmp3_convert_range() (range_mode == 1). With range_mode == 0 the
 * range parameters are ignored and behaviour is exactly v3's.
 */
static int convert_range_impl(const char *in_path, const char *out_path,
                              int bitrate_kbps, int64_t start_us,
                              int64_t end_us, int write_id3,
                              int range_mode)
{
    AVFormatContext *ifmt = NULL;
    AVFormatContext *ofmt = NULL;
    AVCodecContext *dctx = NULL;
    AVCodecContext *ectx = NULL;
    SwrContext *swr = NULL;
    AVAudioFifo *fifo = NULL;
    AVPacket *pkt = NULL;
    AVFrame *dframe = NULL;
    AVFrame *eframe = NULL;
    AVIOContext *out_io = NULL;
    AVIOContext *in_avio = NULL;
    VidMp3StdioAvio *in_ctx = NULL;
    int ret = 0;

    g_errbuf[0] = '\0';
    g_last_percent = -1;

    if (bitrate_kbps <= 0)
        bitrate_kbps = 128;

    /* ---- open input ------------------------------------------------ */
    /* v3: custom 1 MiB-buffered AVIO first (see the helper above);
     * fall back to the plain v1/v2 open if it fails for any reason. */
    ret = vidmp3_open_input_avio(in_path, &ifmt, &in_avio, &in_ctx);
    if (ret < 0)
        ret = avformat_open_input(&ifmt, in_path, NULL, NULL);
    if (ret < 0) {
        set_av_error("Cannot open the input file "
                     "(unsupported format or corrupted data)", ret);
        return -1;
    }
    ret = avformat_find_stream_info(ifmt, NULL);
    if (ret < 0) {
        set_av_error("Cannot read stream information from the input file", ret);
        ret = -2;
        goto fail;
    }

    int astream = av_find_best_stream(ifmt, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    if (astream < 0) {
        set_error("No audio stream found in the input file");
        ret = -3;
        goto fail;
    }
    AVStream *ist = ifmt->streams[astream];

    const AVCodec *dec = avcodec_find_decoder(ist->codecpar->codec_id);
    if (!dec) {
        set_error("Unsupported audio codec in the input file (%s)",
                  avcodec_get_name(ist->codecpar->codec_id));
        ret = -4;
        goto fail;
    }
    dctx = avcodec_alloc_context3(dec);
    if (!dctx) {
        set_error("Out of memory");
        ret = -5;
        goto fail;
    }
    ret = avcodec_parameters_to_context(dctx, ist->codecpar);
    if (ret < 0) {
        set_av_error("Cannot configure the audio decoder", ret);
        ret = -5;
        goto fail;
    }
    ret = avcodec_open2(dctx, dec, NULL);
    if (ret < 0) {
        set_av_error("Cannot open the audio decoder", ret);
        ret = -5;
        goto fail;
    }
    if (dctx->ch_layout.nb_channels < 1)
        av_channel_layout_default(&dctx->ch_layout, dctx->ch_layout.nb_channels > 0
                                        ? dctx->ch_layout.nb_channels : 2);

    /* v4 range mode: seek to (just before) the requested start, then
     * decode forward; sample-accurate trimming happens at the FIFO.
     * No seek for a zero start: the stream is already positioned at
     * the beginning, and seeking to timestamp 0 mislands in some
     * demuxers (observed with mov: it ended up near EOF). */
    if (range_mode && start_us > 0) {
        int64_t start_tb = av_rescale_q(start_us, AV_TIME_BASE_Q,
                                        ist->time_base);
        ret = avformat_seek_file(ifmt, astream, INT64_MIN, start_tb,
                                 start_tb, 0);
        if (ret < 0)
            ret = av_seek_frame(ifmt, astream, start_tb,
                                AVSEEK_FLAG_BACKWARD);
        if (ret < 0) {
            set_av_error("Cannot seek to the requested position "
                         "in the input file", ret);
            ret = -10;
            goto fail;
        }
        avcodec_flush_buffers(dctx);
    }

    /* ---- set up MP3 output ----------------------------------------- */
    const AVCodec *enc = avcodec_find_encoder_by_name("libmp3lame");
    if (!enc) {
        set_error("Internal error: MP3 encoder is not available in this build");
        ret = -6;
        goto fail;
    }
    ret = avformat_alloc_output_context2(&ofmt, NULL, "mp3", NULL);
    if (ret < 0 || !ofmt) {
        set_error("Cannot create the MP3 output");
        ret = -6;
        goto fail;
    }
    AVStream *ost = avformat_new_stream(ofmt, NULL);
    if (!ost) {
        set_error("Out of memory");
        ret = -6;
        goto fail;
    }
    ectx = avcodec_alloc_context3(enc);
    if (!ectx) {
        set_error("Out of memory");
        ret = -6;
        goto fail;
    }

    /* Keep the source sample rate when LAME supports it, else 44.1 kHz. */
    static const int lame_rates[] = {
        8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000
    };
    int sample_rate = dctx->sample_rate > 0 ? dctx->sample_rate : 44100;
    bool rate_ok = false;
    for (size_t i = 0; i < sizeof(lame_rates) / sizeof(lame_rates[0]); i++) {
        if (sample_rate == lame_rates[i]) {
            rate_ok = true;
            break;
        }
    }
    if (!rate_ok)
        sample_rate = 44100;

    int out_channels = dctx->ch_layout.nb_channels;
    if (out_channels < 1) out_channels = 2;
    if (out_channels > 2) out_channels = 2; /* downmix multichannel to stereo */

    ectx->bit_rate = (int64_t)bitrate_kbps * 1000;
    ectx->sample_rate = sample_rate;
    av_channel_layout_default(&ectx->ch_layout, out_channels);
    ectx->sample_fmt = AV_SAMPLE_FMT_S16P;
    ectx->time_base = (AVRational){ 1, sample_rate };

    ret = avcodec_open2(ectx, enc, NULL);
    if (ret < 0) {
        set_av_error("Cannot open the MP3 encoder", ret);
        ret = -7;
        goto fail;
    }
    ret = avcodec_parameters_from_context(ost->codecpar, ectx);
    if (ret < 0) {
        set_av_error("Cannot configure the output stream", ret);
        ret = -7;
        goto fail;
    }
    ost->time_base = ectx->time_base;

    ret = avio_open(&out_io, out_path, AVIO_FLAG_WRITE);
    if (ret < 0) {
        set_av_error("Cannot create the output file", ret);
        ret = -7;
        goto fail;
    }
    ofmt->pb = out_io;
    {
        /* Range segments other than the first are written without an
         * ID3v2 header (id3v2_version=0) so they are raw MP3 frame
         * streams that concatenate directly onto the first segment. */
        AVDictionary *hopts = NULL;
        if (range_mode && !write_id3)
            av_dict_set(&hopts, "id3v2_version", "0", 0);
        ret = avformat_write_header(ofmt, &hopts);
        av_dict_free(&hopts);
    }
    if (ret < 0) {
        set_av_error("Cannot write the MP3 header", ret);
        ret = -7;
        goto fail;
    }

    /* ---- resampler -------------------------------------------------- */
    swr = swr_alloc();
    if (!swr) {
        set_error("Out of memory");
        ret = -8;
        goto fail;
    }
    av_opt_set_chlayout(swr, "in_chlayout", &dctx->ch_layout, 0);
    av_opt_set_int(swr, "in_sample_rate", dctx->sample_rate, 0);
    av_opt_set_sample_fmt(swr, "in_sample_fmt", dctx->sample_fmt, 0);
    av_opt_set_chlayout(swr, "out_chlayout", &ectx->ch_layout, 0);
    av_opt_set_int(swr, "out_sample_rate", sample_rate, 0);
    av_opt_set_sample_fmt(swr, "out_sample_fmt", AV_SAMPLE_FMT_S16P, 0);
    ret = swr_init(swr);
    if (ret < 0) {
        set_av_error("Cannot initialise the audio resampler", ret);
        ret = -8;
        goto fail;
    }

    fifo = av_audio_fifo_alloc(AV_SAMPLE_FMT_S16P, out_channels,
                               ectx->frame_size > 0 ? ectx->frame_size : 1152);
    pkt = av_packet_alloc();
    dframe = av_frame_alloc();
    eframe = av_frame_alloc();
    if (!fifo || !pkt || !dframe || !eframe) {
        set_error("Out of memory");
        ret = -8;
        goto fail;
    }
    eframe->nb_samples = ectx->frame_size;
    eframe->format = AV_SAMPLE_FMT_S16P;
    av_channel_layout_copy(&eframe->ch_layout, &ectx->ch_layout);
    eframe->sample_rate = sample_rate;
    ret = av_frame_get_buffer(eframe, 0);
    if (ret < 0) {
        set_av_error("Out of memory", ret);
        ret = -8;
        goto fail;
    }

    /* Total audio duration for progress: prefer the stream duration. */
    int64_t total_dur = 0;
    if (ist->duration != AV_NOPTS_VALUE && ist->duration > 0) {
        total_dur = ist->duration;
    } else if (ifmt->duration != AV_NOPTS_VALUE && ifmt->duration > 0) {
        total_dur = av_rescale_q(ifmt->duration, AV_TIME_BASE_Q, ist->time_base);
    }

    /* v4 range mode: trimming state + progress range (stream tb). */
    RangeTrim trim;
    RangeTrim *tc = NULL;
    int64_t range_start_tb = 0, range_len_tb = 0;
    if (range_mode) {
        memset(&trim, 0, sizeof(trim));
        trim.start_us = start_us;
        trim.end_us = end_us;
        trim.tb = ist->time_base;
        trim.out_rate = sample_rate;
        tc = &trim;
        range_start_tb = av_rescale_q(start_us, AV_TIME_BASE_Q,
                                      ist->time_base);
        range_len_tb = av_rescale_q(end_us, AV_TIME_BASE_Q,
                                    ist->time_base) - range_start_tb;
    }

    /* ---- decode / resample / encode loop ---------------------------- */
    int64_t next_pts = 0;
    while ((ret = av_read_frame(ifmt, pkt)) >= 0) {
        if (pkt->stream_index != astream) {
            av_packet_unref(pkt);
            continue;
        }
        ret = avcodec_send_packet(dctx, pkt);
        av_packet_unref(pkt);
        if (ret < 0 && ret != AVERROR_INVALIDDATA)
            continue; /* tolerate a bad packet, keep going */
        while ((ret = avcodec_receive_frame(dctx, dframe)) == 0) {
            int64_t pos = dframe->best_effort_timestamp;
            ret = push_decoded_frame(swr, dframe, fifo, ectx, eframe,
                                     &next_pts, ofmt, ost, tc);
            av_frame_unref(dframe);
            if (ret < 0) {
                set_av_error("Conversion failed while encoding audio", ret);
                ret = -9;
                goto fail;
            }
            if (pos != AV_NOPTS_VALUE) {
                if (range_mode) {
                    if (range_len_tb > 0)
                        report_progress(pos - range_start_tb,
                                        range_len_tb);
                } else if (total_dur > 0) {
                    report_progress(pos, total_dur);
                }
            }
            if (tc && tc->done)
                break;
        }
        ret = 0;
        if (tc && tc->done)
            break;
    }

    /* Flush the decoder. */
    avcodec_send_packet(dctx, NULL);
    while (avcodec_receive_frame(dctx, dframe) == 0) {
        ret = push_decoded_frame(swr, dframe, fifo, ectx, eframe,
                                 &next_pts, ofmt, ost, tc);
        av_frame_unref(dframe);
        if (ret < 0) {
            set_av_error("Conversion failed while encoding audio", ret);
            ret = -9;
            goto fail;
        }
    }

    /* Flush the resampler into the FIFO. */
    {
        int64_t delay = swr_get_delay(swr, dctx->sample_rate);
        if (delay > 0) {
            int dst_nb = (int)av_rescale_rnd(delay, sample_rate,
                                             dctx->sample_rate, AV_ROUND_UP);
            if (dst_nb > 0) {
                uint8_t *outbuf[2] = { NULL, NULL };
                ret = av_samples_alloc(outbuf, NULL, out_channels, dst_nb,
                                       AV_SAMPLE_FMT_S16P, 0);
                if (ret >= 0) {
                    int n = swr_convert(swr, outbuf, dst_nb, NULL, 0);
                    if (n > 0)
                        av_audio_fifo_write(fifo, (void **)outbuf, n);
                    av_freep(&outbuf[0]);
                }
            }
        }
        if (!tc) {
            while (av_audio_fifo_size(fifo) >= ectx->frame_size) {
                ret = encode_from_fifo(ectx, fifo, ectx->frame_size, eframe,
                                       &next_pts, ofmt, ost);
                if (ret < 0) {
                    set_av_error("Conversion failed while encoding audio", ret);
                    ret = -9;
                    goto fail;
                }
            }
            int remaining = av_audio_fifo_size(fifo);
            if (remaining > 0) {
                ret = encode_from_fifo(ectx, fifo, remaining, eframe,
                                       &next_pts, ofmt, ost);
                if (ret < 0) {
                    set_av_error("Conversion failed while encoding audio", ret);
                    ret = -9;
                    goto fail;
                }
            }
        } else {
            /* Range mode: drain any pre-start leftovers (normally the
             * skip finished long ago), then encode under the cap. */
            if (tc->skip_remaining > 0) {
                int avail0 = av_audio_fifo_size(fifo);
                int drain = tc->skip_remaining < avail0
                                ? (int)tc->skip_remaining : avail0;
                if (drain > 0) {
                    av_audio_fifo_drain(fifo, drain);
                    tc->skip_remaining -= drain;
                }
            }
            ret = range_encode_available(ectx, fifo, eframe, &next_pts,
                                         ofmt, ost, tc, 1);
            if (ret < 0) {
                set_av_error("Conversion failed while encoding audio", ret);
                ret = -9;
                goto fail;
            }
        }
    }

    /* Flush the encoder and finish the file. */
    avcodec_send_frame(ectx, NULL);
    ret = drain_encoder_packets(ectx, ofmt, ost);
    if (ret < 0) {
        set_av_error("Conversion failed while finishing the MP3 file", ret);
        ret = -9;
        goto fail;
    }
    ret = av_write_trailer(ofmt);
    if (ret < 0) {
        set_av_error("Cannot finalise the MP3 file", ret);
        ret = -9;
        goto fail;
    }

    report_progress(1, 1);
    ret = 0;

fail:
    if (pkt) av_packet_free(&pkt);
    if (dframe) av_frame_free(&dframe);
    if (eframe) av_frame_free(&eframe);
    if (fifo) av_audio_fifo_free(fifo);
    if (swr) swr_free(&swr);
    if (ectx) avcodec_free_context(&ectx);
    if (dctx) avcodec_free_context(&dctx);
    if (ofmt) {
        if (out_io) {
            avio_closep(&out_io);
        }
        avformat_free_context(ofmt);
    }
    if (ifmt)
        avformat_close_input(&ifmt);
    if (in_avio || in_ctx)
        vidmp3_close_input_avio(in_avio, in_ctx);
    return ret;
}

/* ------------------------------------------------------------------ */
/* Public entry points                                                */
/* ------------------------------------------------------------------ */

int vidmp3_convert(const char *in_path, const char *out_path,
                   int bitrate_kbps)
{
    return convert_range_impl(in_path, out_path, bitrate_kbps, 0, 0, 1, 0);
}

/*
 * Convert only the audio in [start_us, end_us) (microseconds).
 * write_id3 != 0: the output gets a normal ID3v2 header, exactly
 * like vidmp3_convert(); write_id3 == 0: no ID3v2 header, so the
 * output is a raw MP3 frame stream that can be concatenated after
 * another segment. Progress is reported within the range.
 */
int vidmp3_convert_range(const char *in_path, const char *out_path,
                         int bitrate_kbps, int64_t start_us,
                         int64_t end_us, int write_id3)
{
    if (end_us <= start_us) {
        set_error("Invalid conversion range (end must be after start)");
        return -11;
    }
    if (start_us < 0)
        start_us = 0;
    return convert_range_impl(in_path, out_path, bitrate_kbps, start_us,
                              end_us, write_id3, 1);
}
